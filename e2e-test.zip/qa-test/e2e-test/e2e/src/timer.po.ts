import { browser, by, element } from 'protractor';

export class TimerPage {
  public navigateTo() {
    return browser.get('/');
  }

  public getHeaderText() {
    return element(by.css('app-root h1')).getText();
  }
}
