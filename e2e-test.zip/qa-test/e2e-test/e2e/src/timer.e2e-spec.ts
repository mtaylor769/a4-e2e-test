import { TimerPage } from './timer.po';

describe('Countdown Timer App', () => {
  let page: TimerPage;

  beforeEach(() => {
    page = new TimerPage();
    page.navigateTo();
  });

  it('should display header', () => {
    expect(page.getHeaderText()).toEqual('Countdown Timer');
  });

  it('should accept user inputted time values', () => {
    // Implement
  });

  it('should show allow starting and stopping of countdown', () => {
    // Implement
  });

  it('should show alert on finished countdown', () => {
    // Implement
  });

  it('should allow resetting of a user inputted time value', () => {
    // Implement
  });


});
